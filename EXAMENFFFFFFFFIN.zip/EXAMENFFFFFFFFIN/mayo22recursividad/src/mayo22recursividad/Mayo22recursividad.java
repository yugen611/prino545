/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo22recursividad;

/**
 *
 * @author itic
 */
public class Mayo22recursividad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   LDobleM lm= new LDobleM();
        lm.Adifinal("ramon", "perro", 3);
        lm.Adifinal("choca", "gato", 2);
        lm.Adifinal("topi", "hamnster", 5);
        lm.Adifinal("rambo", "perro", 7);
        lm.Adifinal("scot", "perro", 4);
        
        
        LDobleM lm2= new LDobleM();
        lm2.Adifinal("richi", "perro", 3);
        lm2.Adifinal("flas", "perro", 2);
        lm2.Adifinal("flipo", "hamnster", 5);
        
        
        LDobleM lm3= new LDobleM();
        lm3.Adifinal("filo", "perro", 3);
        lm3.Adifinal("rafh", "gato", 2);
        
        LDobleM lm4= new LDobleM();
        lm4.Adifinal("tia", "perro", 8);
        lm4.Adifinal("choca", "gato", 2);
        
        LSimpleD d = new LSimpleD();
        d.adifinal("kevin", lm);
        d.adifinal("Aqua", lm2);
        d.adifinal("Ruby", lm3);
        d.adifinal("Ruben", lm4);
     
      
        
        
       
         System.out.println("---------------Procedimiento recursivo---------------");
        mostrar(lm.getP());
        System.out.println("---------------Metodo recursivo---------------");
        lm.mostrar2(lm.getP());
          System.out.println("------------------------------");
         System.out.println("<    mascotas tipo x      >");
         tipoX(lm.getP(),"perro");
         
        System.out.println("------------------------------");
        System.out.println("<    contando mascotas      >");
        contar(lm.getP(),0);
        
        System.out.println("------------------------------");
        System.out.println("<    Existe la mascota con nombre x?      >");
        //monX(lm.getP(),"ramon",false);
        
        System.out.println("------------------------------");
        System.out.println("<    Existe la mascota con nombre x?      >");
        
                System.out.println("------------------------------");
        System.out.println("< LISTA DE DUEÑOS  >");
        mostrarD(d.getP());
        
        //cuantas mascotas tiene cada dueño 
        
        //mostrar a los dueños que tiene mascota tipo x
        duenos(d.getP(),"gato");
        //mostrar a las mascotas del dueño x
        
                 
    }
    public static void  mostrar(NodoM w)
    {
        if(w!=null)
        {
            System.out.println("\t"+w.getNom()+" "+w.getTipo()+" "+w.getEdad());
            mostrar(w.getSig());
        }
        else
             System.out.println("\t"+"FIN DE LISTA");
    }
    public static void  mostrarD(NodoD w)
    {
        if(w!=null)
        {
            System.out.println(w.getNom());
            w.getLm().mostrar2(w.getLm().getP());
            mostrarD(w.getSig());
        }
      
             
    }
    
    public static void  tipoX(NodoM w, String x)
    {
        if(w!=null)
        {
            if(w.getTipo()==x)
                System.out.println("\t"+w.getNom());
            tipoX(w.getSig(),x);
        }
    }
    
    public static void  contar(NodoM w,int c)
    {

        if(w!=null)
        {

            c=c+1;
            contar(w.getSig(),c);
            
        }
        else
            System.out.println("Hay "+ c  +" mascotas");
 
           
    }
    public static void  monX(NodoM w, String x,boolean y)
    {
        if(w!=null)
        {
            if(w.getNom()==x)
                y=true;
            monX(w.getSig(),x,y);
        }
        else
            if(y)
            {
                 System.out.println("\t"+"Si existe la mascota de nombre "+x);
            }
        else
                 System.out.println("\t"+"No existe la mascota de nombre "+x);
    }
    
    public static boolean  verifica(NodoM w, String x)
    {
        if(w!=null)
        {
            if(w.getTipo()==x)
                return true;
            return verifica(w.getSig(),x);
        }
        else
            return false;
    }
    
    public static void  duenos(NodoD w, String x)
    {
        if(w!=null)
        {
            if(verifica(w.getLm().getP(),x))
                System.out.println("\t"+w.getNom());
            duenos(w.getSig(),x);
        }
    }
    
}
