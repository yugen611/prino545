/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo22recursividad;

/**
 *
 * @author itic
 */
public class LSimpleD {
     private NodoD p;
    
    public LSimpleD(){
        p=null;
    }

    public NodoD getP() {
        return p;
    }

    public void setP(NodoD p) {
        this.p = p;
    }
    
    public void adifinal(String a, LDobleM y)
    {
        
      NodoD nue=new NodoD();
        
        nue.setNom(a);
        nue.setLm(y);
       
        if(getP()==null)
        {
            setP(nue);
        }
        else
        {
             NodoD r=getP();
             while(r.getSig()!=null)
             {
                 r=r.getSig();
             }
             r.setSig(nue);
        }
    }
    public void mostrar(){
        NodoD w=getP();
        while(w!=null){
           System.out.println("< "+w.getNom()+ " >");
           w.getLm().Mostrar();
            w=w.getSig();
        }
    }
   public NodoD elifinal()
   {
        if(getP().getSig()==null)
        {
            NodoD w= getP();
            setP(null);
            return w;
          
        }
        else
        {
            NodoD w=getP();
            NodoD r=getP();
            while(w.getSig()!=null)
            {
                r=w;
                w=w.getSig();
               
            }
            r.setSig(null);
            return w;
        }       
   }
   
}
