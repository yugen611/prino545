/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo22recursividad;

/**
 *
 * @author itic
 */
public class LDobleM {
    private NodoM p;
    
    public LDobleM(){
        p=null;
    }

    public NodoM getP() {
        return p;
    }

    public void setP(NodoM p) {
        this.p = p;
    }
    
    public int nronodos()
       {  
           int c=0;
           NodoM r=getP();
           while (r!=null)
           {   c=c+1;
               r = r.getSig();
            }
         return c;
       }
       public void Mostrar()
       {  NodoM r=getP();
          while (r!=null)
          {   
             
              System.out.println("< "+r.getNom()+" "+r.getTipo()+" "+r.getEdad()+" >");
               r=r.getSig();
          }
       }
       public static void  mostrar2(NodoM w)
    {
        if(w!=null)
        {
            System.out.println("\t"+w.getNom()+" "+w.getTipo()+" "+w.getEdad());
            mostrar2(w.getSig());
        }
        else
             System.out.println("\t"+"FIN DE LISTA");
    }
      public void Adiprincipio(String a, String b, int c)
     {    NodoM nue=new NodoM();
          nue.setNom(a);
          nue.setTipo(b);
          nue.setEdad(c);
          if ( getP()==null)
                  setP(nue);
          else{
              nue.setSig(getP());
              getP().setAnt(nue);
              setP(nue);
                      }
     }

         public void Adifinal(String a, String b, int c)
     {    NodoM nue=new NodoM();
          nue.setNom(a);
          nue.setTipo(b);
          nue.setEdad(c);
        
          if (getP()==null)
                  setP(nue);
          else{
               NodoM r=getP();
               while (r.getSig()!=null)
                       r=r.getSig();
               r.setSig(nue);
               nue.setAnt(r);
          }
     }
}
