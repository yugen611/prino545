/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo22recursividad;

/**
 *
 * @author itic
 */
public class NodoD {
    private String nom;
    private LDobleM lm;
    private NodoD sig;
    
    NodoD()
    {
        sig=null;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public LDobleM getLm() {
        return lm;
    }

    public void setLm(LDobleM lm) {
        this.lm = lm;
    }

    public NodoD getSig() {
        return sig;
    }

    public void setSig(NodoD sig) {
        this.sig = sig;
    }
    
    
}
