/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo31_arbolprofundidad;

/**
 *
 * @author itic
 */
public class ABinarioA {
    private NodoA raiz;
    
    ABinarioA()
    {
        raiz=null;
    }

    public NodoA getRaiz() {
        return raiz;
    }

    public void setRaiz(NodoA raiz) {
        this.raiz = raiz;
    }
    
    //metodo crear por profundidad
    public void crear()
    {
        Pila niv=new Pila();
        Pila des=new Pila();
        
        setRaiz(new NodoA());
        Archivo x= new Archivo();
        x.leer();
        getRaiz().setA(x);
        
        niv.adicionar(raiz);
        while(!niv.esvacia())
        {
            while(!niv.esvacia())
            {
                NodoA r= niv.eliminar();
                System.out.println(r.getA().getNom()+" Tendra Izq? s/n");
                String resp =Leer.dato();
                
                if(resp.equals("s"))
                        {
                            NodoA nue= new NodoA ();
                            r.setIzq(nue);
                            Archivo y= new Archivo();
                            y.leer();
                            nue.setA(y);
                            des.adicionar(r.getIzq());
                        }
                System.out.println(r.getA().getNom()+" Tendra Der? s/n");
                
                String res =Leer.dato();
                
                if(res.equals("s"))
                        {
                            NodoA nue= new NodoA ();
                            r.setDer(nue);
                            Archivo y= new Archivo();
                            y.leer();
                            nue.setA(y);
                            des.adicionar(r.getDer());
                        }
                
            }
            niv.vaciar(des);
        }
    }
    public void niveles()
    {
         Pila niv=new Pila();
        Pila des=new Pila();
        niv.adicionar(getRaiz());
        int c= 0;
        while(!niv.esvacia())
        {
            System.out.print("Nivel: "+ c+"----->>");
            while(!niv.esvacia())
            {
                
                NodoA w= niv.eliminar();
                
                
                //procesar nodos
                
                w.getA().mostrar();
                if(w.getIzq()!=null)
                    des.adicionar(w.getIzq());
                if(w.getDer()!=null)
                    des.adicionar(w.getDer());
                
            }
            niv.vaciar(des);
            c++;
            System.out.println("");
            
        }
    }
    
}
