/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo31_arbolprofundidad;

/**
 *
 * @author itic
 */
public class NodoA {
    private NodoA izq, der;
    private Archivo a;
    
    NodoA()
    {
        izq=null;
        der=null;
    }

    public NodoA getIzq() {
        return izq;
    }

    public void setIzq(NodoA izq) {
        this.izq = izq;
    }

    public NodoA getDer() {
        return der;
    }

    public void setDer(NodoA der) {
        this.der = der;
    }

    public Archivo getA() {
        return a;
    }

    public void setA(Archivo a) {
        this.a = a;
    }
    
}
