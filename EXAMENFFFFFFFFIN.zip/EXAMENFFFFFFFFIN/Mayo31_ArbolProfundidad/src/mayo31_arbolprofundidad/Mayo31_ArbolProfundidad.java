/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo31_arbolprofundidad;

/**
 *
 * @author itic
 */
public class Mayo31_ArbolProfundidad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //sea un arbol de archivos (nom, tippo, tam)
        ABinarioA A = new ABinarioA();
        A.crear();
        System.out.println("---------1.mostar arbol----------");
        A.niveles();
        //System.out.println("---------2.mostar nivel k----------");
        //nivelK(A,1);
        //System.out.println("---------3.podar hasta el nivel k----------");
        //podok(A,0);
        //A.niveles();
        System.out.println("---------4.contar los archivos tipo x----------");
        cuentoArX(A,"java");
         System.out.println("---------5.de cada nivel mostrar  el numero de hojas----------");
        NumHojasNiv(A);
          System.out.println("---------6.determinar el mayor tamaño de archivo x----------");
          mayTipoX(A,"java");
    }
    
    public static void nivelK(ABinarioA r , int k)
            
    {
        Pila niv=new Pila();
        Pila des=new Pila();
        niv.adicionar(r.getRaiz());
        int c= 0;
        
        while(!niv.esvacia())
        {
            
        
            while(!niv.esvacia())
            {
                
                NodoA w= niv.eliminar();
                
                
                //procesar nodos
                if(c==k)
                {
                      w.getA().mostrar();
                }
               
                if(w.getIzq()!=null)
                    des.adicionar(w.getIzq());
                if(w.getDer()!=null)
                    des.adicionar(w.getDer());
                
            }
            niv.vaciar(des);
            c++;
            System.out.println("");
            
        }
    }
    public static void podok(ABinarioA r , int k)
            
    {
        Pila niv=new Pila();
        Pila des=new Pila();
        niv.adicionar(r.getRaiz());
        int c= 0;
        
        while(!niv.esvacia())
        {
            if(c == k)
            {
                while(!niv.esvacia())
                {
                    NodoA q= niv.eliminar();
                    q.setIzq(null);
                    q.setDer(null);
                }
            }
        
            while(!niv.esvacia())
            {
                
                NodoA w= niv.eliminar();
                
                
                //procesar nodos
                
               
                if(w.getIzq()!=null)
                    des.adicionar(w.getIzq());
                if(w.getDer()!=null)
                    des.adicionar(w.getDer());
                
            }
            niv.vaciar(des);
            c++;
            System.out.println("");
            
        }
    }
    public static void cuentoArX(ABinarioA r , String k)
            
    {
        Pila niv=new Pila();
        Pila des=new Pila();
        niv.adicionar(r.getRaiz());
        int c= 0;
        
        while(!niv.esvacia())
        {  
            while(!niv.esvacia())
            {                
                NodoA w= niv.eliminar();
                if(w.getA().getTipo().equals(k))
                {
                      c=c+1;
                }
               
                if(w.getIzq()!=null)
                    des.adicionar(w.getIzq());
                if(w.getDer()!=null)
                    des.adicionar(w.getDer());
                
            }
            niv.vaciar(des);

            
        }
        System.out.println(" del tipo "+ k +" hay: ------->> "+c);
    }
    
    public static void NumHojasNiv(ABinarioA r )
            
    {
        Pila niv=new Pila();
        Pila des=new Pila();
        niv.adicionar(r.getRaiz());
        int c= 0;
        int z=0;
        
        while(!niv.esvacia())
        {
            
        
            while(!niv.esvacia())
            {
                
                NodoA w= niv.eliminar();
                
                
                //procesar nodos
                if(w.getIzq()==null && w.getDer()==null)
                {
                      z=z+1;
                }
                if(w.getIzq()!=null)
                    des.adicionar(w.getIzq());
                if(w.getDer()!=null)
                    des.adicionar(w.getDer());
                
            }
            niv.vaciar(des);
            c++;
           System.out.println(" del nivel "+ c +" hay: ------->> "+z+" hojas");
            
        }
        
    }
    public static void mayTipoX(ABinarioA r , String x)
            
    {
        Pila niv=new Pila();
        Pila des=new Pila();
        niv.adicionar(r.getRaiz());
        int may=0;
        
        while(!niv.esvacia())
        {
            
        
            while(!niv.esvacia())
            {
                
                NodoA w= niv.eliminar();
                
                
                //procesar nodos
                if( w.getA().getTipo()==  x )
                {
                    if(w.getA().getTam()> may)
                        may=w.getA().getTam();
                      
                }
                if(w.getIzq()!=null)
                    des.adicionar(w.getIzq());
                if(w.getDer()!=null)
                    des.adicionar(w.getDer());
                
            }
            niv.vaciar(des);
           
            
        }
        System.out.println(" el mayor tamaño del tipo  "+ x +" es: ------->> "+ may);
    }
    
}
