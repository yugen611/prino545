/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo31_arbolprofundidad;

/**
 *
 * @author itic
 */
public class Pila {
    private int max=30;
    private NodoA v[]=new NodoA[max+1];
    private int tope;
    
    Pila() //crea pila vacia
    {
        tope=0;
    }
    boolean esvacia ()
    {
	if (tope == 0)
	    return (true);
	return (false);
    }
    boolean esllena ()
    {
	if (tope == max)
	    return (true);
	return (false);
    }
    int nroelem ()
    {
	return (tope);
    }
    void adicionar (NodoA elem)
    {
	if (!esllena ())
	{
	    tope++;          //v[tope+1]=elem
	    v [tope] = elem; //tope=tope+1
	}
	else
	    System.out.println ("Pila llena");
    }
    NodoA eliminar ()
    {
	NodoA elem =null;
	if (!esvacia ())
	{
	    elem = v [tope];
	    tope--;
	}
	else
	    System.out.println ("Pila vacia");
	return (elem);
    }
 
    void mostrar ()
    {
	if (esvacia ())
	    System.out.println ("Pila vacia");
	else
	{
	 
	    Pila aux = new Pila ();
	    while (!esvacia ())
	    {
		NodoA elem = eliminar ();
                elem.getA().mostrar();
		aux.adicionar (elem);
	    }
	    vaciar(aux);
	}
    }
    void vaciar (Pila a)
    {
	while (!a.esvacia ())
	    adicionar (a.eliminar ());

    }
}
