/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo31_arbolprofundidad;

/**
 *
 * @author itic
 */
public class Archivo {
    private String nom,tipo;
    private int tam;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getTam() {
        return tam;
    }

    public void setTam(int tam) {
        this.tam = tam;
    }
    
    public void leer()
    {
        nom=Leer.dato();
        tipo=Leer.dato();
        tam=Leer.datoInt();
    }
     public void mostrar()
    {
        System.out.print("< "+nom+" "+tipo+" "+tam+" >");
    }
}
