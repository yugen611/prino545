/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo24recursividad;

/**
 *
 * @author itic
 */
public class LDobleP {
    private NodoP p;
    
    public LDobleP(){
        p=null;
    }

    public NodoP getP() {
        return p;
    }

    public void setP(NodoP p) {
        this.p = p;
    }
    
    public int nronodos()
       {  
           int c=0;
           NodoP r=getP();
           while (r!=null)
           {   c=c+1;
               r = r.getSig();
            }
         return c;
       }
       public void Mostrar()
       {  NodoP r=getP();
          while (r!=null)
          {   r.getB().mostrar();
               r=r.getSig();
          }
       }
       public static void  mostrar2(NodoP w)
    {
        if(w!=null)
        {
            w.getB().mostrar();
            mostrar2(w.getSig());
        }
        else
             System.out.println("\t"+"FIN DE LISTA");
    }
       
      public void Adiprincipio(Pagina x)
     {    NodoP nue=new NodoP();
          nue.setB(x);
          if ( getP()==null)
                  setP(nue);
          else{
              nue.setSig(getP());
              getP().setAnt(nue);
              setP(nue);
                      }
     }

         public void Adifinal(Pagina x)
     {    NodoP nue=new NodoP();
          nue.setB(x);
       
          if (getP()==null)
                  setP(nue);
          else{
               NodoP r=getP();
               while (r.getSig()!=null)
                       r=r.getSig();
               r.setSig(nue);
               nue.setAnt(r);
          }
     }
}
