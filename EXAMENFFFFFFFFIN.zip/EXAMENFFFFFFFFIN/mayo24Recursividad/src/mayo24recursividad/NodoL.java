/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo24recursividad;

/**
 *
 * @author itic
 */
public class NodoL {
    private String tipo, texto;
    private NodoL sig;
    
    NodoL()
    {
        sig=null;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public NodoL getSig() {
        return sig;
    }

    public void setSig(NodoL sig) {
        this.sig = sig;
    }
    
    
    
}
