/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo24recursividad;

/**
 *
 * @author itic
 */
public class Pagina {
    private int nroPag;
    private LSimpleL a;
    
    Pagina(int x, LSimpleL y)
    {
        nroPag=x;
        a=y;
    }

    public int getNroPag() {
        return nroPag;
    }

    public void setNroPag(int nroPag) {
        this.nroPag = nroPag;
    }

    public LSimpleL getA() {
        return a;
    }

    public void setA(LSimpleL a) {
        this.a = a;
    }
    
    public void mostrar()
    {
        System.out.println("\t"+nroPag);
        a.mostrar();
    }
    
}
