/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo24recursividad;

/**
 *
 * @author itic
 */
public class LSimpleL {
    private NodoL p;
    
    public LSimpleL(){
        p=null;
    }

    public NodoL getP() {
        return p;
    }

    public void setP(NodoL p) {
        this.p = p;
    }
    
    public void adifinal(String a,String b)
    {
        
      NodoL nue=new NodoL();
        
        nue.setTipo(a);
        nue.setTexto(b);
       
        if(getP()==null)
        {
            setP(nue);
        }
        else
        {
             NodoL r=getP();
             while(r.getSig()!=null)
             {
                 r=r.getSig();
             }
             r.setSig(nue);
        }
    }
    public void mostrar(){
        NodoL w=getP();
        while(w!=null){
           System.out.println("\t"+"\t"+"< "+w.getTipo()+" "+w.getTexto()+" >");
            w=w.getSig();
        }
    }
    
   public NodoL elifinal()
   {
        if(getP().getSig()==null)
        {
            NodoL w= getP();
            setP(null);
            return w;
          
        }
        else
        {
            NodoL w=getP();
            NodoL r=getP();
            while(w.getSig()!=null)
            {
                r=w;
                w=w.getSig();
               
            }
            r.setSig(null);
            return w;
        }       
   }
   
    //mejorado
    //--
     public void adiprincipio(String a, String b)
    {
        NodoL nue=new NodoL();
        
      
        nue.setTipo(a);
        nue.setTexto(b);
       
        
        nue.setSig(getP());
        setP(nue);
    }
    
 
    
}
