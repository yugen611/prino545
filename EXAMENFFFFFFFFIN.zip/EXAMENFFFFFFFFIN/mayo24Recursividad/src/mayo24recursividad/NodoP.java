/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo24recursividad;

/**
 *
 * @author itic
 */
public class NodoP {
    private Pagina b;
    private NodoP ant, sig;
    
    NodoP()
    {
        ant= null;
        sig=null;
    }

    public Pagina getB() {
        return b;
    }

    public void setB(Pagina b) {
        this.b = b;
    }

    public NodoP getAnt() {
        return ant;
    }

    public void setAnt(NodoP ant) {
        this.ant = ant;
    }

    public NodoP getSig() {
        return sig;
    }

    public void setSig(NodoP sig) {
        this.sig = sig;
    }
    
    
}
