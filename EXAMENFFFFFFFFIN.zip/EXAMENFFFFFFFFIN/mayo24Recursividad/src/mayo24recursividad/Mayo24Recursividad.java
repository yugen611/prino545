/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo24recursividad;

/**
 *
 * @author itic
 */
public class Mayo24Recursividad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         LSimpleL l1=new LSimpleL();
        l1.adifinal("titulo", "Rebelion en la granja");
        l1.adifinal("subtitulo", "esta historia comienxa ");
        l1.adifinal("lineaTexto", "El señor Jones, de la Granja Solariega, había echado llave a los gallineros");
       
          l1.adifinal("lineaTexto", "Haciendo bailar de un lado a otro el anillo de luz del farol, se");
        
         LSimpleL l2=new LSimpleL();
         
         l2.adifinal("lineaTexto", "Los dos caballos acababan de acostarse cuando una nidada de patos, que");
         l2.adifinal("lineaTexto", "—Camaradas, ya os habéis enterado del extraño sueño que tuve anoche.");
         
           LSimpleL l3=new LSimpleL();
           l3.adifinal("titulo", "Camaradas, ¿qué sentido tiene vivir como vivimos?");
           
           Pagina p1=new Pagina(1,l1);
           Pagina p2=new Pagina(2,l2);
           Pagina p3=new Pagina(3,l3);
           
           LDobleP lp= new LDobleP();
           lp.Adifinal(p1);
           lp.Adifinal(p2);
           lp.Adifinal(p3);
           
           //lp.Mostrar();
           System.out.println("---------------------crear una lista de paginas y mostrar-----------------------------------");
           mostrar(lp.getP());
             System.out.println("------------------mostar titulos del libro-----------------------------------------------");
           mostrarTit(lp.getP());
             System.out.println("----------------mostar  paginas de numero x------------------------------------------");
           pagX(lp.getP(),2);
           System.out.println("----------------de cada pagina mostar cuantos------------------------------");
           nropag(lp.getP(),1,0,0,0);
    }
    public static void  mostrar(NodoP w)
    {
        if(w!=null)
        {
            w.getB().mostrar();
            mostrar(w.getSig());
        }
        else
             System.out.println("\t"+"FIN DE LISTA");
    }
    
    public static void  mostrarTit(NodoP w)
    {
        if(w!=null)
        {
            Pagina x=w.getB();
            LSimpleL q= x.getA();
            mTit(q.getP());
    
            mostrarTit(w.getSig());
        }
    
            
    }
    
    public static void  mTit(NodoL w)
    {
        if(w!=null)
        {
            if(w.getTipo()=="titulo")
                System.out.println(w.getTexto());
           
    
            mTit(w.getSig());
        }
       
     
    }
    public static void  pagX(NodoP w,int r)
    {
        if(w!=null)
        {
            Pagina x =w.getB();
            if(x.getNroPag()==r)
                 x.getA().mostrar();
    
            pagX(w.getSig(),r);
        }
    
            
    }
    
    
      public static void nropag(NodoP w,int x, int a , int b, int c)
    {
        if(w!=null)
        {
            if(w.getB().getNroPag()==x)
            {
                a=suma(w.getB().getA().getP(), a,"titulo");
                b=suma(w.getB().getA().getP(), b,"subtitulo");
                c=suma(w.getB().getA().getP(),c,"lineaTexto" );
            }
            nropag(w.getSig(),x,a,b,c);

        }
        else
            System.out.println("nro pagina = "+x+"; nro  titulos = " +a+ "; nro subtitulos = "+b +"; nro Lineas de texto = "+c);
       
     
    }
      public static int  suma(NodoL w,int r,String y)
    {
        if(w!=null)
        {
          
            if(w.getTipo()==y)
                 r=r+1;
    
            return suma(w.getSig(),r,y);
        }
        else 
            return r;
    
            
    }
    
    
    
    
}
