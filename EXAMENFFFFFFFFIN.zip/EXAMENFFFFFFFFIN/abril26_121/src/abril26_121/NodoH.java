/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abril26_121;

/**
 *
 * @author estudiante
 */
public class NodoH {
    private String instructor , dia, horario;
    private int cupo;
    private LSimpleI li;
    private NodoH sig;
    
    NodoH(){
        sig=null;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public int getCupo() {
        return cupo;
    }

    public void setCupo(int cupo) {
        this.cupo = cupo;
    }

    public LSimpleI getLi() {
        return li;
    }

    public void setLi(LSimpleI li) {
        this.li = li;
    }

    public NodoH getSig() {
        return sig;
    }

    public void setSig(NodoH sig) {
        this.sig = sig;
    }
    
    
    
    
}
