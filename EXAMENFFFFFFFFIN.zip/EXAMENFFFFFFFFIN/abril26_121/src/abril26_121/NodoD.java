/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abril26_121;

/**
 *
 * @author estudiante
 */
public class NodoD {
    private String nombre, tipo;
    private int donde, hasta;
    
    private LSimpleH lh;
    private NodoD sig ;
    
    NodoD(){
        sig=null;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getDonde() {
        return donde;
    }

    public void setDonde(int donde) {
        this.donde = donde;
    }

    public int getHasta() {
        return hasta;
    }

    public void setHasta(int hasta) {
        this.hasta = hasta;
    }

    public LSimpleH getLh() {
        return lh;
    }

    public void setLh(LSimpleH lh) {
        this.lh = lh;
    }

    public NodoD getSig() {
        return sig;
    }

    public void setSig(NodoD sig) {
        this.sig = sig;
    }
    
    
    
}
