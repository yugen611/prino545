/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abril26_121;

/**
 *
 * @author estudiante
 */
public class LSimpleH {
    private NodoH p;
    
    LSimpleH(){
        p=null;
    }

    public NodoH getP() {
        return p;
    }

    public void setP(NodoH p) {
        this.p = p;
    }
    
    public void adicionar (String a, String b, String c, int d, LSimpleI e){
        NodoH nue =new NodoH();
        nue.setInstructor(a);
        nue.setDia(b);
        nue.setHorario(c);
        nue.setCupo(d);
        nue.setLi(e);
        if(getP()==null)
            setP(nue);
        else{
            NodoH r= getP();
            while(r.getSig()!=null)
            {
                r=r.getSig();
            }
            r.setSig(nue);
        }
        
    }
    
    public void mostar(){
        
        NodoH r=getP();
        while(r!=null)
        {
            System.out.println("\t"+" < "+r.getInstructor()+" "+r.getHorario()+" "+r.getDia()+" "+r.getCupo()+">");
            r.getLi().mostar();
            r=r.getSig();
        }
        
    }
    
}
