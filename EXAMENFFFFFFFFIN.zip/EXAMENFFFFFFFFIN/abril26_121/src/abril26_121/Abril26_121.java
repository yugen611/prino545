/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abril26_121;

/**
 *
 * @author estudiante
 */
public class Abril26_121 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //sean las listas simples 
        //lsitas de disiplinas(nombre,desde hasta tipo Listas de horarios
        //lista de horarios (instructor ,dia horario,cupo lista de isncritos)
        //lista de isncritos (ci nom pat mat gen edad)
        
        //
        LSimpleI A= new LSimpleI();
        A.adicionar(111, "juan", "perez", "prez", "masculino", 15);
        A.adicionar(222, "marco", "toro", "jon", "masculino", 35);
        A.adicionar(333, "rial", "perez", "jun", "masculino", 19);
        LSimpleI B= new LSimpleI();
        B.adicionar(444, "juana", "delano", "arco", "femenino", 23);
        B.adicionar(555, "jon", "cos", "rai", "masculino", 19);
        B.adicionar(666, "joel", "perez", "maamni", "masculino", 19);
        LSimpleI C= new LSimpleI();
        C.adicionar(777, "tiel", "clos", "rosas", "masculino", 19);
        C.adicionar(888, "lied", "gil", "roy", "masculino", 25);
        C.adicionar(999, "sara", "roy", "cald", "femenino", 20);
        LSimpleI D= new LSimpleI();
        D.adicionar(000, "lla", "gex", "rout", "masculino", 19);
        D.adicionar(0001, "liss", "trol", "rety", "masculino", 25);
        D.adicionar(0002, "sora", "fin", "cassert", "femenino", 20);
        LSimpleI E= new LSimpleI();
        E.adicionar(0003, "rios", "pins", "dws", "masculino", 19);
        E.adicionar(0004, "cleo", "jol", "reut", "masculino", 25);
        E.adicionar(0005, "briar", "font", "sra", "femenino", 20);
        LSimpleI F= new LSimpleI();
        F.adicionar(0006, "trio", "joss", "roy", "masculino", 19);
        F.adicionar(0007, "duoi", "erto", "wddw", "masculino", 25);
        F.adicionar(9978, "yoiut", "srtou", "fert", "femenino", 20);
        LSimpleI G= new LSimpleI();
        G.adicionar(9862, "certo", "oiuy", "roy", "masculino", 19);
        G.adicionar(7897, "sore", "srtu", "wddw", "masculino", 25);
        G.adicionar(359, "risat", "dwd", "fert", "femenino", 20);
        LSimpleI H = new LSimpleI();
        H.adicionar(2663, "cleens", "juyss", "ryuoi", "masculino", 19);
        H.adicionar(3496, "sans", "stre", "erert", "masculino", 25);
        H.adicionar(326, "char", "sdter", "ertu", "femenino", 20);
       
        
        LSimpleH A1 = new LSimpleH();
        A1.adicionar("roel", "lunes", "10-12", 3, A);
        A1.adicionar("mary", "martes", "8-10", 2, B);
        
        LSimpleH A2 = new LSimpleH();
        A2.adicionar("miguel", "martes", "10-12", 3, C);
        A2.adicionar("suk", "jueves", "8-10", 2, D);
        
        LSimpleH A3 = new LSimpleH();
        A3.adicionar("roy", "domingo", "10-12", 3, E);
        A3.adicionar("lidia", "sabado", "10-16", 3, F);
        
        LSimpleH A4 = new LSimpleH();
        A4.adicionar("seut", "miercoles", "15-18", 0, G);
        A4.adicionar("lisa", "miercoles", "8-10", 0, H);
        
        LSimpleD B1= new LSimpleD();
        B1.adicionar("futbool","grupal" , 125, 225, A1);
        B1.adicionar("ajedres", "individual", 36, 26, A2);
        B1.adicionar("jockey", "grupal", 45, 336, A3);
        B1.adicionar( "boxeo", "individual", 3, 15, A4);
        
        System.out.println("--1.mostrar list de disiplinas----");
        B1.mostar();
        System.out.println("--2.msotar instructor dia , hora de la disiplina x----");
        displinaX(B1,"boxeo");
        System.out.println("--3.cuantos inscritos existen en cada disiplina----");
        contar(B1);
        System.out.println("--4.dela disiplina x mostar  a inscritos con edad y----");
        disEdadY(B1,"futbool",19);

        
        
        
    }
    public static void contar (LSimpleD a)
    {
        NodoD r= a.getP();
        while(r!=null)
        {
            System.out.println("DISIPLINA: "+r.getNombre()+" "+cuenta(r.getLh()));
            r=r.getSig();
        }
    }
    public static int cuenta(LSimpleH a)
    {
        int t=0;
        NodoH r= a.getP();
        while(r!=null)
        {
            t=t+conteo(r.getLi());
            r=r.getSig();
        }
        return t;
    }
    public static int conteo(LSimpleI a)
    {
        int c=0;
        NodoI r=a.getP();
        while(r!=null)
        {
            c++;
            r=r.getSig();
        }
        return c;
    }
    public static void displinaX(LSimpleD a, String x)
    {
        NodoD r= a.getP();
        while(r!=null)
        {
            if(r.getNombre()==x)
            {
                NodoH w=r.getLh().getP();
                while(w!=null)
                {
                    System.out.println(w.getInstructor()+" "+w.getDia()+" "+w.getHorario());
                    w=w.getSig();
                }
            }
            r=r.getSig();
        }
    }
    public static void disEdadY(LSimpleD a, String x,int y)
    {
        NodoD r= a.getP();
        while(r!=null)
        {
            if(r.getNombre()==x)
            {
                NodoH w=r.getLh().getP();
                while(w!=null)
                {
                    NodoI z=w.getLi().getP();
                    while(z!=null)
                    {
                        if(z.getEdad()==y)
                            System.out.println(z.getNom()+" "+z.getPat()+" "+z.getMat());
                        z=z.getSig();
                    }
                    w=w.getSig();
                }
            }
            r=r.getSig();
        }
    }
            
}
