/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abril26_121;

/**
 *
 * @author estudiante
 */
public class LSimpleI {
    private NodoI p;
    
    LSimpleI(){
        p=null;
    }

    public NodoI getP() {
        return p;
    }

    public void setP(NodoI p) {
        this.p = p;
    }
    
    public void adicionar (int a, String b, String c, String d, String e,int  f){
        NodoI nue =new NodoI();
        nue.setCi(a);
        nue.setNom(b);
        nue.setPat(c);
        nue.setMat(d);
        nue.setGenero(e);
        nue.setEdad(f);
        if(getP()==null)
            setP(nue);
        else{
            NodoI r= getP();
            while(r.getSig()!=null)
            {
                r=r.getSig();
            }
            r.setSig(nue);
        }
        
    }
    
    public void mostar(){
        
        NodoI r=getP();
        while(r!=null)
        {
            System.out.println("\t"+"\t"+" < "+r.getCi()+" "+r.getNom()+" "+r.getPat()+" "+r.getMat()+" "+r.getGenero()+" >");
            r=r.getSig();
        }
        
    }
    
}
