/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abril26_121;

/**
 *
 * @author estudiante
 */
public class LSimpleD {
    private NodoD p;
    
    LSimpleD(){
        p=null;
    }

    public NodoD getP() {
        return p;
    }

    public void setP(NodoD p) {
        this.p = p;
    }
    
    public void adicionar (String a, String b, int c, int d, LSimpleH e){
        NodoD nue =new NodoD();
        nue.setNombre(a);
        nue.setTipo(b);
        nue.setDonde(c);
        nue.setHasta(d);
        nue.setLh(e);
        if(getP()==null)
            setP(nue);
        else{
            NodoD r= getP();
            while(r.getSig()!=null)
            {
                r=r.getSig();
            }
            r.setSig(nue);
        }
        
    }
    
    public void mostar(){
        
        NodoD r=getP();
        while(r!=null)
        {
            System.out.println(" < "+r.getNombre()+" "+r.getTipo()+" "+r.getDonde()+" "+r.getHasta()+">");
            r.getLh().mostar();
            r=r.getSig();
        }
        
    }

    
}
