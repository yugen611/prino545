/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package junio5arbolbinariobusqueda;

/**
 *
 * @author itic
 */
public class Producto {
    private String nom;
    private int prec;
    
    Producto(String a, int b)
    {
        nom=a;
        prec=b;
    }
    
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getPrec() {
        return prec;
    }

    public void setPrec(int prec) {
        this.prec = prec;
    }
    
    
    public void mostrar()
    {
        System.out.println("< "+nom+" "+prec+" >");
    }
    public void leer()
    {
        System.out.println("producto------->");
        nom=Leer.dato();
        prec=Leer.datoInt();
    }
    
}
