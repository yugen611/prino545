/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package junio5arbolbinariobusqueda;

/**
 *
 * @author itic
 */
public class ArbolBBP {
    private NodoP raiz;
    
    ArbolBBP()
    {
        raiz=null;
    }

    public NodoP getRaiz() {
        return raiz;
    }

    public void setRaiz(NodoP raiz) {
        this.raiz = raiz;
    }
    public void agregar1(Producto px)
    {
        NodoP nue=new NodoP();
        nue.setP(px);
        if (getRaiz() == null)
                {
                   setRaiz(nue); 
                }
        else
        {
            NodoP r= getRaiz();
            boolean sw=true;
            while(sw)
            {
                if(px.getPrec()> r.getP().getPrec())
                {
                    if(r.getDer()!=null )
                        r=r.getDer();
                    else
                    {
                        r.setDer(nue);
                        sw=false;
                    }
                }
                else
                    if(px.getPrec()<r.getP().getPrec())
                    {
                        if(r.getIzq() !=null)
                        {
                            r=r.getIzq();
                        }
                        else
                        {
                            r.setDer(nue);
                            sw=false;
                        }
                        
                    }
                    else
                    {
                        System.out.println("ya existe");
                        sw=false;
                    }
             
            }
        }
    }
    
    public void inorden(NodoP r)
    {
        
        if(r!=null)
        {
            inorden(r.getIzq());
            r.getP().mostrar();
            inorden(r.getDer());
        }
    }
    public void agregarN(int n)
    {
        
        for(int i =0 ; i<n; i++)
        {
            System.out.println("producto------->");
            String r=Leer.dato();
            int y=Leer.datoInt();
            Producto nue = new Producto(r,y);
            agregar1(nue);
            
           
            
        }
    }
    public void mayores2(int x)
    {
        NodoP r= getRaiz();
        while(r!=null)
        {
            if(x== r.getP().getPrec())
            {
                inorden(r.getDer());
                r=null;
            }
            else
            {
                if(x>r.getP().getPrec())
                    r=r.getDer();
                else
                    if(x>r.getP().getPrec())
                    {
                        r.getP().mostrar();
                        inorden(r.getDer());
                        r=r.getIzq();
                    }
            }
        }
    }
    public void buscar(int x)
    {
        NodoP r=getRaiz();
        while(r!=null)
        {
            if(x> r.getP().getPrec())
                r=r.getDer();
            else
            {
                if(x<r.getP().getPrec())
                    r=r.getIzq();
                else
                {
                    System.out.println(May(r));
                    System.out.println(Men(r));
                    r=null;
                }
            }
        }
    }
    public   String May(NodoP r)
    {
        
        while(r.getDer()!=null)
            r=r.getDer();
        return r.getP().getNom();
    }
     public String  Men(NodoP r)
    {
       
        while(r.getIzq()!=null)
            r=r.getIzq();
        return r.getP().getNom();
    }
    
        
       
}
