/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package junio5arbolbinariobusqueda;

/**
 *
 * @author itic
 */
public class Junio5ArbolBinarioBusqueda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //sea de un arbol binario de busqueda cuyos nodos almacena objetos producto
        //producto(nombre, precio )
        //
        
        ArbolBBP A = new ArbolBBP();
        //A.agregar1(new Producto("frijor",7));
        A.agregarN(4);
        A.inorden(A.getRaiz());
        
          System.out.println("productso con mayor y menor precio");
        MayMen(A);
         System.out.println("del sub arbol raiz  con precion x");
         A.buscar(1);
        System.out.println("productos  con  precio mayores que x");
        A.mayores2(5);
    }
    public static  NodoP  May(NodoP r)
    {
        
        while(r.getDer()!=null)
            r=r.getDer();
        return r;
    }
     public static  NodoP  Men(NodoP r)
    {
       
        while(r.getIzq()!=null)
            r=r.getIzq();
        return r;
    }
      public static  void  MayMen(ArbolBBP A)
    {
        NodoP r= May(A.getRaiz());
        NodoP s= Men(A.getRaiz());
        System.out.println("el mayor es----> "+r.getP().getNom());
        System.out.println("el menor  es----> "+s.getP().getNom());
    }
      
    
}
