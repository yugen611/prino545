/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package junio5arbolbinariobusqueda;

/**
 *
 * @author itic
 */
public class NodoP {
    private NodoP izq, der;
    private Producto p;
    
    NodoP ()
    {
        izq=null;
        der=null;
    }

    public NodoP getIzq() {
        return izq;
    }

    public void setIzq(NodoP izq) {
        this.izq = izq;
    }

    public NodoP getDer() {
        return der;
    }

    public void setDer(NodoP der) {
        this.der = der;
    }

    public Producto getP() {
        return p;
    }

    public void setP(Producto p) {
        this.p = p;
    }
    
    
}
