/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo29_arbol;

/**
 *
 * @author itic
 */
public class Mayo29_Arbol {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ArbolBV B = new ArbolBV();
        B.setRaiz(new NodoV());
        System.out.println("---------------1.crear---------------");
        B.crear(B.getRaiz());
        B.preorden(B.getRaiz());
        System.out.println("---------------2.inorden---------------");
        B.inorden(B.getRaiz());
        System.out.println("---------------3.posorden---------------");
        B.posorden(B.getRaiz());
        System.out.println("---------------4.mostrar vedura  con color x---------------");
        VerdurasX(B.getRaiz(),"verde");
        System.out.println("---------------5.contar verduras de color x---------------");
        System.out.println(ContarColX(B.getRaiz(),"verde"));
        ;
  
    }
    
    public static void VerdurasX(NodoV r, String x)
    {
         if(r!=null)
        {
          
           if(r.getIzq()==null && r.getDer()== null && r.getColor().equals(x))
           {
               System.out.println(r.getNonbre()+" "+r.getColor());
                    
           }
            VerdurasX(r.getIzq(),x);
            VerdurasX(r.getDer(),x);
            
        }
    }
    
     public static int  ContarColX(NodoV r, String x)
    {
         if(r!=null)
        {
            int c = ContarColX(r.getIzq(),x)+ ContarColX(r.getDer(),x);
            
            if( r.getColor()==x )
            {
              c=c+1;
                    
            }
            return c;
        }
         else
             return 0;
         
    }
     
     public static void SubArbol(NodoV r, String x)
    {
         if(r!=null)
        {
          
           if( r.getNonbre().equals(x))
           {
               System.out.println();
               mostrarSub(r.)
                    
           }
            SubArbol(r.getIzq(),x);
            SubArbol(r.getDer(),x);
            
        }
    }
     
    
     
    
}
