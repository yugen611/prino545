/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo29_arbol;

/**
 *
 * @author itic
 */
public class ArbolBV {
    
    private NodoV raiz;
    
    ArbolBV(){
        raiz=null;
    }

    public NodoV getRaiz() {
        return raiz;
    }

    public void setRaiz(NodoV raiz) {
        this.raiz = raiz;
    }
    
    public void crear(NodoV r)
    {
        if(r!=null)
        {
            r.setNonbre(Leer.dato());
            r.setColor(Leer.dato());
            
            System.out.println(r.getNonbre()+" Tendra Izq s/n ");
            
            String resp= Leer.dato();
            if(resp.equals("s"))
            {
                NodoV nue = new NodoV ();
                r.setIzq(nue);
                crear(r.getIzq());
               
            }
            
           
            System.out.println(r.getNonbre()+" Tendra Der s/n ");
             resp= Leer.dato();
            if(resp.equals("s"))
            {
                NodoV nue = new NodoV ();
                r.setDer(nue);
                crear(r.getDer());
              
            }
        }
    }
    public void preorden(NodoV r)
    {
        if(r!=null)
        {
            System.out.println(r.getNonbre()+" "+r.getColor());
            preorden(r.getIzq());
            preorden(r.getDer());
            
        }
    }
    public void inorden(NodoV r)
    {
        if(r!=null)
        {
            inorden(r.getIzq());
            System.out.println(r.getNonbre()+" "+r.getColor());
           
            inorden(r.getDer());
            
        }
    }
     public void posorden(NodoV r)
    {
        if(r!=null)
        {
           
            posorden(r.getIzq());
            posorden(r.getDer());
            System.out.println(r.getNonbre()+" "+r.getColor());
            
        }
    }
    
    
}
