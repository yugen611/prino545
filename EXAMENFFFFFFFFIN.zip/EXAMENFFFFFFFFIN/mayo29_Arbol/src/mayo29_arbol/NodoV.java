/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mayo29_arbol;

/**
 *
 * @author itic
 */
public class NodoV {
    private String  nonbre, color;
    private NodoV izq, der;
    
    NodoV ()
    {
        izq=null;
        der=null;
    }

    public String getNonbre() {
        return nonbre;
    }

    public void setNonbre(String nonbre) {
        this.nonbre = nonbre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public NodoV getIzq() {
        return izq;
    }

    public void setIzq(NodoV izq) {
        this.izq = izq;
    }

    public NodoV getDer() {
        return der;
    }

    public void setDer(NodoV der) {
        this.der = der;
    }
    
    
}
